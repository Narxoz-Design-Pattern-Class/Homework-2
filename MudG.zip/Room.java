package mud_game;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class Room implements IRoom {
    private String name;
    private String description;
    private Map<String, Room> exits;
    private List<Item> items;
    private List<NPC> npcs;

    public Room(String name, String description) {
        this.name = name;
        this.description = description;
        this.exits = new HashMap<>();
        this.items = new ArrayList<>();
        this.npcs = new ArrayList<>();
    }

    public void setExit(String direction, Room room) {
        exits.put(direction, room);
    }

    public Room getExit(String direction) {
        return exits.get(direction);
    }

    public void addItem(Item item) {
        items.add(item);
    }

    public void removeItem(Item item) {
        items.remove(item);
    }

    public Item getItem(String itemName) {
        return items.stream().filter(item -> item.getName().equalsIgnoreCase(itemName)).findFirst().orElse(null);
    }

    public void addNPC(NPC npc) {
        npcs.add(npc);
    }
    public List<NPC> getNPCs() {
        return npcs;
    }

    public String describe() {
        StringBuilder sb = new StringBuilder();
        sb.append("Room: ").append(name).append("\n").append(description).append("\n");
        if (!items.isEmpty()) {
            sb.append("Items here: ");
            for (Item item : items) {
                sb.append(item.getName()).append(", ");
            }
            sb.delete(sb.length() - 2, sb.length());
            sb.append("\n");
        }
        if (!npcs.isEmpty()) {
            sb.append("NPCs present: ");
            for (NPC npc : npcs) {
                sb.append(npc.getName()).append(", ");
            }
            sb.delete(sb.length() - 2, sb.length());
            sb.append("\n");
        }
        return sb.toString();
    }
}
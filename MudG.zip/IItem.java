package mud_game;

import java.util.*;

interface IItem {
    String getName();
}
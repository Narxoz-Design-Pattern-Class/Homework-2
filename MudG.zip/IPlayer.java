package mud_game;
import java.util.List;

interface IPlayer {
    Room getCurrentRoom();
    void setCurrentRoom(Room room);
    void addItem(Item item);
    List<Item> getInventory();
}
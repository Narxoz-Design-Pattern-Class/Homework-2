package mud_game;

interface IRoom {
    void setExit(String direction, Room room);
    Room getExit(String direction);
    void addItem(Item item);
    void removeItem(Item item);
    Item getItem(String itemName);
    String describe();
}
